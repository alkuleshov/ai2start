import os, sys, tempfile, unittest
from datetime import datetime, timedelta, timezone
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
os.environ["DB_PATH"] = tempfile.mktemp(suffix=".db")
from app import config, slots, store, catalog

MSK = config.TZ
def dt(y, m, d, h=0, mi=0): return datetime(y, m, d, h, mi, tzinfo=MSK)

class Slots(unittest.TestCase):
    def test_only_weekdays_and_fixed_hours(self):
        now = dt(2026, 10, 19, 9, 0)           # понедельник
        c = slots.candidate_starts(now)
        self.assertTrue(all(s.weekday() < 5 for s in c))
        self.assertTrue(all((s.hour, s.minute) in config.START_TIMES for s in c))
        self.assertLessEqual(len(c), 22 * 4)

    def test_min_notice_12h(self):
        now = dt(2026, 10, 19, 9, 0)
        c = slots.candidate_starts(now)
        self.assertNotIn(dt(2026, 10, 19, 10), c)     # через 1 час — рано
        self.assertNotIn(dt(2026, 10, 19, 19), c)     # через 10 часов — рано
        self.assertIn(dt(2026, 10, 20, 10), c)

    def test_weekend_skipped(self):
        c = slots.candidate_starts(dt(2026, 10, 23, 9))   # пятница
        self.assertNotIn(dt(2026, 10, 24, 10), c)
        self.assertNotIn(dt(2026, 10, 25, 10), c)
        self.assertIn(dt(2026, 10, 26, 10), c)

    def test_busy_and_buffer(self):
        busy = [(dt(2026, 10, 20, 11, 0), dt(2026, 10, 20, 12, 0))]
        self.assertFalse(slots.is_free(dt(2026, 10, 20, 10), 60, busy))   # конец встречи 11:00 + буфер до 30 мин -> упирается
        self.assertFalse(slots.is_free(dt(2026, 10, 20, 12), 60, busy))   # после занятого нужен час
        self.assertTrue(slots.is_free(dt(2026, 10, 20, 14), 60, busy))
        self.assertTrue(slots.is_free(dt(2026, 10, 20, 19), 60, busy))

    def test_long_service_blocks_next_slot(self):
        busy = [(dt(2026, 10, 20, 14, 0), dt(2026, 10, 20, 15, 0))]
        self.assertFalse(slots.is_free(dt(2026, 10, 20, 12), 150, busy))  # 12:00-14:30 пересекает

    def test_utc_events(self):
        busy = [(datetime(2026, 10, 20, 7, 0, tzinfo=timezone.utc), datetime(2026, 10, 20, 8, 0, tzinfo=timezone.utc))]  # 10:00–11:00 Мск
        self.assertFalse(slots.is_free(dt(2026, 10, 20, 10), 60, busy))

    def test_parse_roundtrip(self):
        s = slots.parse_local("2026-10-20T14:00")
        self.assertEqual(slots.from_epoch(slots.to_epoch(s)), s)

class Store(unittest.TestCase):
    def test_hold_expiry_and_paid(self):
        t = store.now()
        base = dict(kind="slot", service="homework", title="x", amount=1990, name="a", email="a@b.ru", consent_at=t, created=t, duration_min=60)
        s0 = slots.to_epoch(dt(2026, 11, 2, 10))
        store.insert(id="p1", status="pending", hold_until=t + 600, slot_start=s0, **base)
        store.insert(id="p2", status="pending", hold_until=t - 5, slot_start=s0 + 7200, **base)
        store.insert(id="p3", status="paid", hold_until=t - 5, slot_start=s0 + 14400, **base)
        starts = sorted(int(b0.timestamp()) for b0, _ in store.db_busy())
        self.assertEqual(starts, [s0, s0 + 14400])     # просроченная удержка не считается

    def test_stream_seats(self):
        t = store.now()
        base = dict(kind="stream", service="parents-course", title="x", amount=2990, name="a", email="a@b.ru", consent_at=t, created=t, stream_id="parents")
        store.insert(id="s1", status="paid", hold_until=t, **base)
        store.insert(id="s2", status="pending", hold_until=t + 100, **base)
        store.insert(id="s3", status="pending", hold_until=t - 100, **base)
        self.assertEqual(store.stream_taken("parents"), 2)

    def test_outbox_and_alert_dedupe(self):
        store.alert_once("k", "boom"); store.alert_once("k", "boom")
        items = store.outbox_pending()
        self.assertEqual(len([i for i in items if "boom" in i["text"]]), 1)
        store.outbox_ack([i["id"] for i in items])
        self.assertEqual(store.outbox_pending(), [])

class Catalog(unittest.TestCase):
    def test_items(self):
        self.assertEqual(catalog.slot_item("homework")[1:], (1990, 60))
        self.assertEqual(catalog.slot_item("pack-1")[1], 9900)
        self.assertIsNone(catalog.slot_item("pack-9"))
        self.assertIsNone(catalog.slot_item("parents-course"))
        self.assertIsNone(catalog.slot_item("nope"))

if __name__ == "__main__":
    unittest.main(verbosity=2)
