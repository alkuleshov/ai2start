"""Заявка -> подтверждение -> оплата. Сеть (ЮKassa, почта) подменяется."""
import os, sys, tempfile, types, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
os.environ["DB_PATH"] = tempfile.mktemp(suffix=".db")
os.environ["NOTIFY_KEY"] = "test-key-for-signing"
sys.modules.setdefault("httpx", types.ModuleType("httpx"))
from app import config, flow, slots, store
config.NOTIFY_KEY = "test-key-for-signing"

H = 3600
mails, payments = [], {}

def fake_send(to, subj, body): mails.append((to, subj, body))
def fake_create(bid, amount, title, email, return_url, idem=None):
    pid = f"p{len(payments)+1}"; url = f"https://yoomoney.test/{pid}"
    payments[pid] = {"id": pid, "status": "pending", "confirmation": {"confirmation_url": url},
                     "metadata": {"booking_id": bid}}
    return pid, url
def fake_get(pid): return payments[pid]
flow.mailer.send = fake_send
flow.yookassa.create_payment = fake_create
flow.yookassa.get_payment = fake_get

class _SyncThread:
    """В проде письмо уходит в фоновом потоке (чтобы не держать HTTP-ответ брони);
    в тестах подменяем на синхронный вызов, чтобы assert видел результат сразу."""
    def __init__(self, target=None, daemon=None, name=None):
        self._target = target
    def start(self):
        self._target()
flow.threading.Thread = _SyncThread

def mk(start_in_h=48, name="Анна", status="requested", hold=None):
    t = store.now(); start = t + start_in_h * H
    bid = store.new_id()
    store.insert(id=bid, status=status, kind="slot", service="homework", title="Помощник по домашке",
                 amount=1990, slot_start=start, duration_min=60, name=name, email="a@b.ru", contact="",
                 consent_at=t, created=t, hold_until=hold if hold is not None else flow.request_hold_until(start, t))
    return store.get(bid)

def outbox_texts(): return [r["text"] for r in store.db().execute("SELECT text FROM outbox ORDER BY id")]


class Flow(unittest.TestCase):
    def setUp(self):
        mails.clear(); payments.clear()
        store.db().execute("DELETE FROM bookings"); store.db().execute("DELETE FROM outbox"); store.db().execute("DELETE FROM kv")

    def tearDown(self):
        store.db().execute("DELETE FROM bookings"); store.db().execute("DELETE FROM outbox"); store.db().execute("DELETE FROM kv")

    def test_request_hold_clamped_before_meeting(self):
        t = 1_000_000
        self.assertEqual(flow.request_hold_until(t + 100 * H, t), t + 24 * H)
        self.assertEqual(flow.request_hold_until(t + 14 * H, t), t + 11 * H)
        self.assertEqual(flow.pay_hold_until(t + 5 * H, t), t + 4 * H)

    def test_requested_holds_slot_and_notifies(self):
        b = mk()
        self.assertEqual(len(store.db_busy()), 1)
        self.assertEqual(store.db_busy(exclude=b["id"]), [])
        flow.on_requested(b)
        self.assertIn("Заявка получена", mails[0][1])
        self.assertIn("ничего платить не нужно", mails[0][2])
        self.assertIn(flow.admin_url(b["id"]), outbox_texts()[0])

    def test_no_personal_data_in_telegram(self):
        old = mk(hold=store.now() - 5, name="Анна Секретная")
        waiting = mk(name="Анна Секретная"); store.update(waiting["id"], created=store.now() - 4 * H)
        flow.on_requested(waiting); flow.tick_requests()
        pend = mk(status="pending", hold=store.now() + H, name="Анна Секретная"); store.update(pend["id"], approved_at=1)
        flow.on_pay_expired(store.get(pend["id"]))
        for t in outbox_texts():
            self.assertNotIn("Секретная", t); self.assertNotIn("a@b.ru", t)

    def test_signature(self):
        b = mk()
        self.assertTrue(flow.check_sig(b["id"], flow.sign(b["id"])))
        self.assertFalse(flow.check_sig(b["id"], "0" * 32))
        self.assertFalse(flow.check_sig(b["id"], ""))
        self.assertFalse(flow.check_sig("other", flow.sign(b["id"])))

    def test_approve_then_pay(self):
        b = mk()
        with self.assertRaises(flow.FlowError):
            flow.payment_url(b["id"])                 # до подтверждения платить нельзя
        b2, changed = flow.approve(b["id"])
        self.assertTrue(changed)
        self.assertEqual(b2["status"], "pending")
        self.assertIn("✅ Подтверждено", outbox_texts()[-1])   # владелец в Telegram видит исход нажатия
        before = len(outbox_texts())
        flow.approve(b["id"])                          # повторное нажатие не шлёт второе уведомление
        self.assertEqual(len(outbox_texts()), before)
        self.assertLessEqual(b2["hold_until"], b2["slot_start"] - H)
        self.assertIn(flow.pay_url(b["id"]), mails[-1][2])
        self.assertFalse(flow.approve(b["id"])[1])    # повторное нажатие ничего не ломает
        u1 = flow.payment_url(b["id"]); u2 = flow.payment_url(b["id"])
        self.assertEqual(u1, u2)                      # незакрытый платёж переиспользуется
        payments["p1"]["status"] = "canceled"
        u3 = flow.payment_url(b["id"])
        self.assertNotEqual(u1, u3)                   # после отмены — новый платёж
        self.assertEqual(len(store.db_busy()), 1)     # окно всё ещё держится

    def test_approve_expired_request(self):
        b = mk(hold=store.now() - 10)
        with self.assertRaises(flow.FlowError):
            flow.approve(b["id"])
        self.assertEqual(store.get(b["id"])["status"], "expired")

    def test_approve_too_close(self):
        b = mk(start_in_h=1.2, hold=store.now() + 600)
        with self.assertRaises(flow.FlowError):
            flow.approve(b["id"])

    def test_decline_frees_slot_with_note(self):
        b = mk()
        b2, changed = flow.decline(b["id"], "Могу в четверг в 19:00")
        self.assertTrue(changed)
        self.assertEqual(b2["status"], "declined")
        self.assertEqual(store.db_busy(), [])
        self.assertIn("четверг", mails[-1][2])
        self.assertIn("не списывались", mails[-1][2])
        self.assertIn("❌ Отклонено", outbox_texts()[-1])      # владелец в Telegram видит исход нажатия
        self.assertIn("четверг", outbox_texts()[-1])

    def test_pay_after_deadline(self):
        b = mk(status="pending", hold=store.now() - 5)
        with self.assertRaises(flow.FlowError):
            flow.payment_url(b["id"])

    def test_tick_expires_and_nudges_once(self):
        old = mk(hold=store.now() - 5)
        waiting = mk()
        store.update(waiting["id"], created=store.now() - 4 * H)
        flow.tick_requests(); flow.tick_requests()
        self.assertEqual(store.get(old["id"])["status"], "expired")
        self.assertEqual(store.get(waiting["id"])["status"], "requested")
        texts = outbox_texts()
        self.assertEqual(sum("⏰" in x for x in texts), 1)
        self.assertEqual(sum("⌛" in x for x in texts), 1)
        self.assertTrue(any("Не успели подтвердить" in m[1] for m in mails))

    def test_admin_page_escapes(self):
        b = mk(name='<script>alert(1)</script>')
        page = flow.admin_page(b, flow.sign(b["id"]))
        self.assertNotIn("<script>alert", page)
        self.assertIn("Подтвердить", page)
        self.assertIn("Отклонить", page)
        done = flow.admin_page(dict(b, status="paid"), "k")
        self.assertNotIn("<form", done)

    def test_calendar_conflict(self):
        b = mk()
        start = slots.from_epoch(b["slot_start"])
        self.assertFalse(flow.calendar_conflict(b, []))
        self.assertTrue(flow.calendar_conflict(b, [(start, start)]))


if __name__ == "__main__":
    unittest.main()
