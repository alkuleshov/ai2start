"""Копия заявок в Google-таблицу: формат строки и повторы при сбое."""
import json, os, sys, tempfile, types, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
os.environ.setdefault("DB_PATH", tempfile.mktemp(suffix=".db"))
sys.modules.setdefault("httpx", types.ModuleType("httpx"))
from app import config, sheets, store

sent, fail = [], {"on": False}
class R:
    def __init__(self, code): self.status_code = code
def fake_post(url, content=b"", headers=None, timeout=None, follow_redirects=False):
    if fail["on"]: return R(500)
    sent.append(json.loads(content.decode())); return R(200)
sheets.httpx.post = fake_post

class Sheets(unittest.TestCase):
    def setUp(self):
        sent.clear(); fail["on"] = False; config.SHEET_WEBHOOK_URL = "https://script.test/exec"
        for t in ("leads", "outbox", "kv"): store.db().execute(f"DELETE FROM {t}")
    tearDown = setUp

    def test_row_format_and_retry(self):
        store.lead_add("waitlist", "parents-course", "Курс «ИИ для родителей»", "Анна", "a@b.ru", "+7900", "после 18:00")
        fail["on"] = True; sheets.sync()
        self.assertEqual(sent, []); self.assertEqual(len(store.leads_unsynced()), 1)
        fail["on"] = False; sheets.sync()
        self.assertEqual(len(sent), 1); self.assertEqual(store.leads_unsynced(), [])
        p = sent[0]
        self.assertEqual((p["name"], p["phone"], p["email"], p["course"]), ("Анна", "+7900", "a@b.ru", "Курс «ИИ для родителей»"))
        self.assertIn("лист ожидания", p["source"]); self.assertIn("после 18:00", p["comment"])
        self.assertTrue(p["timestamp"].endswith("Z"))
        sheets.sync(); self.assertEqual(len(sent), 1)      # второй раз не шлём

    def test_off_without_url(self):
        config.SHEET_WEBHOOK_URL = ""
        store.lead_add("waitlist", "x", "x", "a", "a@b.ru"); sheets.sync()
        self.assertEqual(sent, [])

    def test_dedupe_window(self):
        store.lead_add("waitlist", "parents-course", "t", "a", "a@b.ru")
        self.assertTrue(store.lead_recent("parents-course", "a@b.ru"))
        self.assertFalse(store.lead_recent("voice-planner", "a@b.ru"))

if __name__ == "__main__":
    unittest.main()
