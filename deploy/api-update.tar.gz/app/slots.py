"""Окна: чистая логика без сети и базы, чтобы её можно было проверить тестами."""
from datetime import datetime, timedelta, timezone
from . import config

def candidate_starts(now, days_ahead=None, min_notice_h=None):
    """Все возможные начала встреч (aware, Мск): пн–пт, фиксированные часы."""
    days_ahead = config.DAYS_AHEAD if days_ahead is None else days_ahead
    min_notice_h = config.MIN_NOTICE_H if min_notice_h is None else min_notice_h
    now = now.astimezone(config.TZ)
    earliest = now + timedelta(hours=min_notice_h)
    day = now.date()
    out = []
    for i in range(days_ahead + 1):
        d = day + timedelta(days=i)
        if d.weekday() not in config.WEEKDAYS:
            continue
        for h, m in config.START_TIMES:
            s = datetime(d.year, d.month, d.day, h, m, tzinfo=config.TZ)
            if s >= earliest:
                out.append(s)
    return out

def is_free(start, duration_min, busy,
            before=None, after=None):
    """busy: список (начало, конец) aware. Свободно, если ничто не пересекается
    со встречей с учётом отступов до и после."""
    before = config.BUFFER_BEFORE_MIN if before is None else before
    after = config.BUFFER_AFTER_MIN if after is None else after
    end = start + timedelta(minutes=duration_min)
    for b0, b1 in busy:
        if b0 - timedelta(minutes=before) < end and b1 + timedelta(minutes=after) > start:
            return False
    return True

def free_slots(now, duration_min, busy):
    return [s for s in candidate_starts(now) if is_free(s, duration_min, busy)]

def parse_local(text):
    """'2026-10-20T10:00' -> aware datetime Мск"""
    return datetime.strptime(text, "%Y-%m-%dT%H:%M").replace(tzinfo=config.TZ)

def fmt_local(dt):
    dt = dt.astimezone(config.TZ)
    wd = ["пн", "вт", "ср", "чт", "пт", "сб", "вс"][dt.weekday()]
    mon = ["янв", "фев", "мар", "апр", "мая", "июн", "июл", "авг", "сен", "окт", "ноя", "дек"][dt.month - 1]
    return f"{wd}, {dt.day} {mon}, {dt:%H:%M} (Мск)"

def to_epoch(dt):
    return int(dt.astimezone(timezone.utc).timestamp())

def from_epoch(ts):
    return datetime.fromtimestamp(ts, tz=timezone.utc).astimezone(config.TZ)
