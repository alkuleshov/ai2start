"""Публикация уведомлений владельцу в файл queue.jsonl ветки GitHub.
Каждое сообщение шифруется (Fernet, ключ NOTIFY_KEY есть только на этом сервере и в Париже),
поэтому в репозитории лежит только шифртекст. Бот в Париже читает файл и шлёт в Telegram.
"""
import base64
import json
import logging
import time

import httpx
from cryptography.fernet import Fernet

from . import config, store

log = logging.getLogger("publisher")
API = "https://api.github.com"
KEEP_LINES = 300


def enabled():
    return bool(config.GH_TOKEN and config.GH_REPO and config.NOTIFY_KEY)


def _hdr():
    return {"Authorization": f"Bearer {config.GH_TOKEN}", "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28", "User-Agent": "ai2start-api"}


def publish_once():
    items = store.outbox_pending(limit=20)
    if not items:
        return 0
    f = Fernet(config.NOTIFY_KEY.encode())
    url = f"{API}/repos/{config.GH_REPO}/contents/queue.jsonl"
    with httpx.Client(timeout=20, headers=_hdr()) as c:
        r = c.get(url, params={"ref": config.GH_BRANCH})
        r.raise_for_status()
        cur = r.json()
        old = base64.b64decode(cur["content"]).decode("utf-8", "replace").splitlines()
        old = [l for l in old if l.strip()]
        new = [json.dumps({"id": it["id"], "c": f.encrypt(str(it["text"]).encode()).decode()}, separators=(",", ":"))
               for it in items]
        body = "\n".join((old + new)[-KEEP_LINES:]) + "\n"
        p = c.put(url, json={"message": "queue", "branch": config.GH_BRANCH, "sha": cur["sha"],
                             "content": base64.b64encode(body.encode()).decode()})
        p.raise_for_status()
    store.outbox_ack([it["id"] for it in items])
    return len(items)


def loop():
    while True:
        try:
            publish_once()
        except Exception as e:
            log.warning("publish: %s", e)
        time.sleep(20)
