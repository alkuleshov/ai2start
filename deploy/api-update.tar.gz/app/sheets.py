"""Копия заявок в общую Google-таблицу через Apps Script (тот же скрипт, что принимает заявки ai2arch).
Колонки таблицы: Дата, ФИО, Телефон, Email, Образование, Право на удостоверение, Комментарий, Источник, Курс, Трэк.
Основная копия хранится в базе на сервере в РФ; в таблицу отправляем, пока не получится (до 50 попыток)."""
import json
import logging
from datetime import datetime, timezone

import httpx

from . import config, store

log = logging.getLogger("sheets")
KIND_RU = {"waitlist": "лист ожидания", "booking": "заявка на встречу"}


def payload(lead):
    return {
        "name": lead["name"], "phone": lead["contact"] or "", "email": lead["email"],
        "education": "", "certEligible": "",
        "comment": " · ".join(x for x in (config.SHEET_SOURCE, KIND_RU.get(lead["kind"], lead["kind"]),
                                          lead["title"], lead["comment"] or "") if x),
        "timestamp": datetime.fromtimestamp(lead["created"], tz=timezone.utc).isoformat().replace("+00:00", "Z"),
        "course": lead["title"], "track": KIND_RU.get(lead["kind"], lead["kind"]),
        "source": f"{config.SHEET_SOURCE} — {KIND_RU.get(lead['kind'], lead['kind'])}",
    }


def send(lead):
    r = httpx.post(config.SHEET_WEBHOOK_URL, content=json.dumps(payload(lead), ensure_ascii=False).encode(),
                   headers={"Content-Type": "text/plain;charset=utf-8"}, timeout=25, follow_redirects=True)
    return r.status_code < 400


def sync():
    if not config.SHEET_WEBHOOK_URL:
        return
    for lead in store.leads_unsynced():
        try:
            ok = send(lead)
        except Exception as e:
            log.warning("таблица: %s", e)
            ok = False
        store.lead_mark(lead["id"], ok)
        if not ok:
            store.alert_once("sheet", "Не удаётся записать заявку в Google-таблицу, повторю позже. Заявки сохранены на сервере.")
            break
