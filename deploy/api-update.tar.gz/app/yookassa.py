import httpx

from . import config

API = "https://api.yookassa.ru/v3"

def _client():
    return httpx.Client(auth=(config.YK_SHOP_ID, config.YK_SECRET), timeout=20)

def create_payment(booking_id, amount_rub, title, email, return_url, idem=None):
    value = f"{amount_rub:.2f}"
    body = {
        "amount": {"value": value, "currency": "RUB"},
        "capture": True,
        "confirmation": {"type": "redirect", "return_url": return_url},
        "description": f"ai2start: {title}"[:128],
        "metadata": {"booking_id": booking_id},
        "receipt": {
            "customer": {"email": email},
            "tax_system_code": config.YK_TAX_SYSTEM,
            "items": [{
                "description": title[:128], "quantity": "1.00",
                "amount": {"value": value, "currency": "RUB"},
                "vat_code": config.YK_VAT_CODE,
                "payment_subject": "service", "payment_mode": "full_payment",
            }],
        },
    }
    with _client() as c:
        r = c.post(f"{API}/payments", json=body, headers={"Idempotence-Key": idem or booking_id})
        r.raise_for_status()
        p = r.json()
    return p["id"], p["confirmation"]["confirmation_url"]

def get_payment(payment_id):
    with _client() as c:
        r = c.get(f"{API}/payments/{payment_id}")
        r.raise_for_status()
        return r.json()
