import socket
import smtplib
import ssl
from email.message import EmailMessage

from . import config

# Многие VPS/докер-хосты не имеют маршрута в IPv6, а DNS иногда отдаёт
# AAAA-запись первой — тогда соединение падает с "Network is unreachable".
# Режем резолвинг только на IPv4 для всего процесса.
_orig_getaddrinfo = socket.getaddrinfo
def _ipv4_only_getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):
    res = _orig_getaddrinfo(host, port, socket.AF_INET, type, proto, flags)
    return res or _orig_getaddrinfo(host, port, family, type, proto, flags)
socket.getaddrinfo = _ipv4_only_getaddrinfo


def send(to, subject, body):
    if not (config.SMTP_USER and config.SMTP_PASSWORD):
        raise RuntimeError("SMTP не настроен")
    m = EmailMessage()
    m["From"] = f"ai2start <{config.MAIL_FROM}>"
    m["To"] = to
    m["Subject"] = subject
    m["Reply-To"] = config.MAIL_FROM
    m.set_content(body)
    with smtplib.SMTP_SSL(config.SMTP_HOST, config.SMTP_PORT, context=ssl.create_default_context(), timeout=25) as s:
        s.login(config.SMTP_USER, config.SMTP_PASSWORD)
        s.send_message(m)
