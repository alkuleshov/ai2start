import smtplib
import ssl
from email.message import EmailMessage

from . import config

def send(to, subject, body):
    if not (config.SMTP_USER and config.SMTP_PASSWORD):
        raise RuntimeError("SMTP не настроен")
    m = EmailMessage()
    m["From"] = f"ai2start <{config.MAIL_FROM}>"
    m["To"] = to
    m["Subject"] = subject
    m["Reply-To"] = config.MAIL_FROM
    m.set_content(body)
    with smtplib.SMTP_SSL(config.SMTP_HOST, config.SMTP_PORT, context=ssl.create_default_context(), timeout=25) as s:
        s.login(config.SMTP_USER, config.SMTP_PASSWORD)
        s.send_message(m)
