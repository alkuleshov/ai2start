"""Цены и услуги — единственный источник правды. Цену из браузера сервер не принимает."""
import json
from . import config

# id: (название, цена ₽, длительность занятого времени в минутах)
SERVICES = {
    "ai-access":       ("ChatGPT, Claude и Gemini: доступ и оплата", 2990, 60),
    "own-agent":       ("Свой ИИ-агент", 4990, 90),
    "automation":      ("Агент-автоматизация", 9900, 180),
    "deep-research":   ("Глубокое исследование", 1990, 60),
    "vibe-site":       ("Сайт за вечер вместе с нейросетью", 4990, 120),
    "site-launch":     ("Запуск сайта: домен, хостинг, HTTPS", 4990, 120),
    "site-turnkey":    ("Сайт с заявками под ключ", 14900, 60),      # 60 мин — стартовый созвон, дальше работа 2–3 дня
    "voice-ai":        ("ИИ-собеседник в телефоне", 1990, 60),
    "second-brain":    ("Второй мозг в NotebookLM", 2490, 60),
    "job-search":      ("Резюме и собеседование с ИИ", 2490, 90),
    "marketplace":     ("Карточки для маркетплейсов", 3990, 90),
    "travel":          ("Путешествие с ИИ", 1990, 60),
    "neuro-photo":     ("Нейрофотосессия", 1990, 60),
    "revive-photo":    ("Оживить старое фото", 1490, 60),
    "homework":        ("Помощник по домашке", 1990, 60),
    "exam-tutor":      ("ИИ-репетитор к ОГЭ и ЕГЭ", 3990, 90),
    "calendar":        ("Настройка календаря", 2490, 60),
    "family-sync":     ("Синхронизация семьи", 3990, 90),
    "mail":            ("Расчистка почты", 3990, 90),
    "mail-pro":        ("Почта PRO", 6990, 150),
    "meetings":        ("Саммари встреч", 2990, 60),
    "style":           ("Тексты в вашем стиле", 2490, 60),
    "ai-setup":        ("Настройка ИИ-ассистента", 2990, 120),
    "budget":          ("Семейный бюджет", 2990, 60),
    "committee":       ("Бюджет родкомитета", 1990, 60),
    "excel":           ("Порядок в таблицах", 7900, 60),
    "subscriptions":   ("Аудит подписок", 1990, 60),
    "tg-bot":          ("Telegram-бот", 14900, 60),
    "district":        ("Проверка района", 7900, 60),
    "renovation":      ("Ремонт по фото", 4990, 60),
    "plot":            ("Проверка участка под дом", 9900, 60),
}
PACKS = [
    ("Старт с ИИ", 4990),
    ("Семейный порядок", 9900),
    ("Порядок в работе", 17900),
]
WAITLIST = {                 # «Хочу первым»: что можно ждать
    "parents-course": "Курс «ИИ для родителей»",
    "family-intensive": "Интенсив «Родитель + ребёнок»",
    "voice-planner": "Бот «голос → календарь»",
}
STREAM_SERVICES = {          # услуги, продающиеся потоками
    "parents-course": ("Курс «ИИ для родителей»", 2990),
    "family-intensive": ("Интенсив «Родитель + ребёнок»", 5990),
}

def slot_item(service_id):
    """-> (название, цена, минуты) для услуги с записью на окно или None"""
    if service_id.startswith("pack-"):
        try:
            t, p = PACKS[int(service_id[5:])]
        except (ValueError, IndexError):
            return None
        return f"Пакет «{t}»", p, 60
    s = SERVICES.get(service_id)
    return s if s else None

def load_streams():
    """streams.json лежит в /data и правится без пересборки. Нет файла — потоков нет."""
    try:
        with open(config.STREAMS_PATH, encoding="utf-8") as f:
            items = json.load(f)
    except (OSError, ValueError):
        return []
    out = []
    for s in items:
        if s.get("service") in STREAM_SERVICES and s.get("dates") and s.get("time"):
            out.append(s)
    return out
