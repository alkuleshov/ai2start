"""Запись на встречу: заявка -> подтверждение владельцем -> оплата.
Здесь нет FastAPI и сети календаря, поэтому логику можно проверять тестами.

Статусы встречи (kind=slot):
  requested  заявка, ждёт ответа владельца, окно удержано до hold_until
  pending    владелец подтвердил, ждём оплату до hold_until
  paid       оплачено
  declined   владелец отклонил
  expired    не ответили вовремя или не оплатили вовремя
Потоки курсов (kind=stream) по-прежнему оплачиваются сразу: даты фиксированы.
"""
import hashlib
import hmac
import html
import logging
from datetime import datetime, timedelta, timezone

from . import catalog, config, mailer, slots, store, yookassa

log = logging.getLogger("flow")
SUPPORT = "https://t.me/ai2start_bot"


class FlowError(Exception):
    def __init__(self, code, msg):
        super().__init__(msg)
        self.code = code


# ---------- ссылки ----------
def _key():
    return (config.ADMIN_KEY or config.NOTIFY_KEY or config.OUTBOX_TOKEN).encode()

def sign(bid):
    return hmac.new(_key(), f"admin:{bid}".encode(), hashlib.sha256).hexdigest()[:32]

def check_sig(bid, k):
    return bool(_key()) and bool(k) and hmac.compare_digest(sign(bid), str(k))

def admin_url(bid):
    return f"{config.API_PUBLIC_URL}/admin/b/{bid}?k={sign(bid)}"

def status_url(bid):
    return f"{config.SITE_URL}/?booking={bid}"

def pay_url(bid):
    return f"{config.SITE_URL}/?booking={bid}&pay=1"


# ---------- время ----------
def stream_when(s):
    d = ", ".join(f"{x[8:10]}.{x[5:7]}" for x in s["dates"])
    return f"{d} · {s['time']} (Мск)"

def booking_when(b):
    if b["kind"] == "slot":
        return slots.fmt_local(slots.from_epoch(b["slot_start"]))
    s = next((x for x in catalog.load_streams() if x["id"] == b["stream_id"]), None)
    return stream_when(s) if s else "по расписанию потока"

def fmt_deadline(ts):
    return slots.fmt_local(slots.from_epoch(ts)).replace(" (Мск)", "") + " (Мск)"

def request_hold_until(slot_start, t):
    return min(t + config.REQUEST_HOLD_H * 3600, slot_start - 3 * 3600)

def pay_hold_until(slot_start, t):
    return min(t + config.PAY_HOLD_H * 3600, slot_start - 3600)


def _mail(b, subject, body):
    try:
        mailer.send(b["email"], subject, body)
        return True
    except Exception as e:
        log.warning("mail: %s", e)
        store.alert_once("mail", f"Не ушло письмо клиенту ({b['title']}): {safe_err(b, e)}\n{admin_url(b['id'])}")
        return False

def _client_line(b):
    """Персональные данные клиента не уходят в Telegram (сервер за рубежом): только ссылка
    на страницу заявки, которая открывается с российского сервера."""
    return f"Клиент и детали: {admin_url(b['id'])}"

def safe_err(b, e):
    return str(e).replace(b.get("email") or "\0", "<почта клиента>")


# ---------- шаги ----------
def on_requested(b):
    """заявка создана: письмо клиенту, уведомление владельцу со ссылкой на решение"""
    _mail(b, f"Заявка получена: {b['title']}",
          f"Здравствуйте, {b['name']}!\n\n"
          f"Мы получили заявку: {b['title']}\nВремя: {booking_when(b)}\nСтоимость: {b['amount']} ₽\n\n"
          f"Подтвердим, что время свободно, до {fmt_deadline(b['hold_until'])}. "
          "Сразу после этого пришлём ссылку на оплату. Пока ничего платить не нужно.\n\n"
          f"Статус заявки: {status_url(b['id'])}\n"
          f"Вопросы: {SUPPORT}\n\nai2start.ru")
    store.outbox_add(f"🆕 Заявка: {b['title']} · {b['amount']} ₽\n{booking_when(b)}\n"
                     f"Ответить до {fmt_deadline(b['hold_until'])}\n"
                     f"Подтвердить или отклонить: {admin_url(b['id'])}")


def calendar_conflict(b, busy_external):
    """есть ли в календаре что-то новое поверх этой заявки (своё удержание не считаем)"""
    if b["kind"] != "slot":
        return False
    others = list(busy_external) + store.db_busy(exclude=b["id"])
    return not slots.is_free(slots.from_epoch(b["slot_start"]), b["duration_min"], others)


def approve(bid):
    with store.LOCK:
        b = store.get(bid)
        if not b:
            raise FlowError(404, "Заявка не найдена")
        if b["status"] != "requested":
            return b, False
        t = store.now()
        if b["hold_until"] <= t:
            store.update(bid, status="expired")
            raise FlowError(409, "Заявка уже истекла, клиенту ушло письмо. Предложите ему другое время.")
        until = pay_hold_until(b["slot_start"], t)
        if until - t < 30 * 60:
            raise FlowError(409, "До встречи слишком мало времени на оплату. Отклоните заявку и предложите другое время.")
        store.update(bid, status="pending", hold_until=until, approved_at=t)
        b = store.get(bid)
    _mail(b, f"Время подтверждено, оплатите до {fmt_deadline(b['hold_until'])}",
          f"Здравствуйте, {b['name']}!\n\n"
          f"Время свободно, ждём вас: {b['title']}\nКогда: {booking_when(b)}\nСтоимость: {b['amount']} ₽\n\n"
          f"Оплатить: {pay_url(bid)}\n\n"
          f"Окно держим за вами до {fmt_deadline(b['hold_until'])}. Если не оплатить до этого времени, оно освободится.\n"
          "Чек пришлёт ЮKassa отдельным письмом.\n"
          f"Вопросы: {SUPPORT}\n\nai2start.ru")
    return b, True


def decline(bid, note=""):
    note = (note or "").strip()[:600]
    with store.LOCK:
        b = store.get(bid)
        if not b:
            raise FlowError(404, "Заявка не найдена")
        if b["status"] not in ("requested", "pending"):
            return b, False
        store.update(bid, status="declined")
        b = store.get(bid)
    extra = f"\n{note}\n" if note else ""
    _mail(b, f"Это время не получится: {b['title']}",
          f"Здравствуйте, {b['name']}!\n\n"
          f"К сожалению, {booking_when(b)} не получится провести встречу «{b['title']}».\n{extra}\n"
          "Деньги не списывались. Выберите другое удобное время на сайте: "
          f"{config.SITE_URL}/#schedule\nИли напишите нам, подберём вместе: {SUPPORT}\n\n"
          "Извините за неудобство.\nai2start.ru")
    return b, True


def payment_url(bid):
    """ссылка на оплату подтверждённой заявки: переиспользуем незакрытый платёж или создаём новый"""
    with store.LOCK:
        b = store.get(bid)
        if not b:
            raise FlowError(404, "Запись не найдена")
        if b["status"] == "paid":
            raise FlowError(409, "Эта встреча уже оплачена")
        if b["status"] == "requested":
            raise FlowError(409, "Время ещё не подтверждено. Ссылка на оплату придёт на почту.")
        if b["status"] != "pending":
            raise FlowError(409, "Срок оплаты истёк или запись отменена. Выберите новое время.")
        t = store.now()
        if b["hold_until"] <= t:
            raise FlowError(409, "Срок оплаты истёк. Выберите новое время.")
        if b["payment_id"]:
            p = yookassa.get_payment(b["payment_id"])
            url = (p.get("confirmation") or {}).get("confirmation_url")
            if p.get("status") == "pending" and url:
                return url
            if p.get("status") == "succeeded":
                raise FlowError(409, "Оплата уже прошла, подтверждение придёт на почту")
        pid, url = yookassa.create_payment(bid, b["amount"], b["title"], b["email"], status_url(bid),
                                           idem=f"{bid}-{t}")
        store.update(bid, payment_id=pid)
        return url


def tick_requests():
    """истёкшие заявки и напоминания владельцу"""
    t = store.now()
    for r in store.db().execute("SELECT * FROM bookings WHERE status='requested' AND hold_until<=?", (t,)).fetchall():
        b = dict(r)
        store.update(b["id"], status="expired")
        store.outbox_add(f"⌛ Заявка истекла без ответа: {b['title']} · {booking_when(b)}\n{_client_line(b)}")
        _mail(b, f"Не успели подтвердить заявку: {b['title']}",
              f"Здравствуйте, {b['name']}!\n\nМы не успели подтвердить время {booking_when(b)}, извините. "
              "Деньги не списывались.\n"
              f"Выберите другое время: {config.SITE_URL}/#schedule\nИли напишите: {SUPPORT}\n\nai2start.ru")
    for r in store.db().execute("SELECT * FROM bookings WHERE status='requested' AND created<?",
                                (t - config.NUDGE_AFTER_H * 3600,)).fetchall():
        b = dict(r)
        if not store.kv_get("nudge:" + b["id"]):
            store.kv_set("nudge:" + b["id"], 1)
            store.outbox_add(f"⏰ Заявка ждёт ответа до {fmt_deadline(b['hold_until'])}: {b['title']} · {booking_when(b)}\n"
                             f"{admin_url(b['id'])}")


def on_pay_expired(b):
    """подтверждённая встреча не оплачена вовремя"""
    if b["kind"] != "slot" or not b.get("approved_at"):
        return
    store.outbox_add(f"⌛ Не оплатили вовремя, окно освобождено: {b['title']} · {booking_when(b)}\n{_client_line(b)}")
    _mail(b, f"Срок оплаты истёк: {b['title']}",
          f"Здравствуйте, {b['name']}!\n\nОкно {booking_when(b)} освободилось: оплата не поступила вовремя. "
          "Деньги не списывались.\n"
          f"Если всё ещё актуально, выберите время заново: {config.SITE_URL}/#schedule\n"
          f"Вопросы: {SUPPORT}\n\nai2start.ru")


# ---------- страница владельца ----------
STATUS_RU = {"requested": "ждёт вашего ответа", "pending": "подтверждено, ждём оплату", "paid": "оплачено",
             "declined": "отклонено", "expired": "истекло", "paid_conflict": "оплачено, но время занято"}

def admin_page(b, k, msg="", conflict=False):
    e = html.escape
    rows = [("Услуга", b["title"]), ("Когда", booking_when(b)), ("Сумма", f"{b['amount']} ₽"),
            ("Клиент", b["name"]), ("Почта", b["email"]), ("Контакт", b.get("contact") or "—"),
            ("Статус", STATUS_RU.get(b["status"], b["status"]))]
    if b["status"] in ("requested", "pending"):
        rows.append(("Держим окно до", fmt_deadline(b["hold_until"])))
    table = "".join(f"<tr><th>{e(a)}</th><td>{e(str(v))}</td></tr>" for a, v in rows)
    warn = ('<p class="warn">⚠️ В календаре на это время появилось другое событие. '
            'Проверьте, прежде чем подтверждать.</p>') if conflict and b["status"] == "requested" else ""
    note = f'<p class="msg">{e(msg)}</p>' if msg else ""
    act = ""
    if b["status"] == "requested":
        act = f"""
<form method="post" action="/admin/b/{e(b['id'])}/approve"><input type="hidden" name="k" value="{e(k)}">
<button class="ok">Подтвердить: клиенту придёт ссылка на оплату</button></form>"""
    if b["status"] in ("requested", "pending"):
        act += f"""
<form method="post" action="/admin/b/{e(b['id'])}/decline"><input type="hidden" name="k" value="{e(k)}">
<label>Комментарий клиенту (необязательно)<textarea name="note" maxlength="600" rows="3"
placeholder="Например: могу в четверг в 19:00 — запишитесь на это время"></textarea></label>
<button class="no">Отклонить</button></form>"""
    return f"""<!doctype html><html lang="ru"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex">
<title>Заявка · ai2start</title><style>
:root{{color-scheme:light dark;--bg:#f6f4fb;--fg:#1b1530;--card:#fff;--line:#e3def0}}
@media (prefers-color-scheme:dark){{:root{{--bg:#140f22;--fg:#f2eefc;--card:#1f1834;--line:#342a50}}}}
body{{margin:0;background:var(--bg);color:var(--fg);font:16px/1.45 system-ui,-apple-system,Segoe UI,sans-serif}}
main{{max-width:520px;margin:0 auto;padding:20px 16px 40px}}
h1{{font-size:22px;margin:0 0 14px}}
table{{width:100%;border-collapse:collapse;background:var(--card);border-radius:14px;overflow:hidden}}
th,td{{text-align:left;padding:10px 12px;border-bottom:1px solid var(--line);vertical-align:top}}
th{{width:40%;font-weight:600;opacity:.7}}
form{{margin-top:16px;display:grid;gap:10px}}
label{{display:grid;gap:6px;font-size:14px}}
textarea{{font:inherit;padding:10px;border-radius:12px;border:1px solid var(--line);background:var(--card);color:var(--fg)}}
button{{font:inherit;font-weight:700;border:0;border-radius:999px;padding:14px 18px;cursor:pointer}}
.ok{{background:#2fbf71;color:#fff}} .no{{background:transparent;color:#e0476b;box-shadow:inset 0 0 0 2px #e0476b}}
.msg{{background:var(--card);border-radius:12px;padding:12px}} .warn{{background:#fff3cd;color:#5c4400;border-radius:12px;padding:12px}}
</style></head><body><main><h1>Заявка на встречу</h1>{note}{warn}<table>{table}</table>{act}</main></body></html>"""
