import hmac
import logging
from urllib.parse import parse_qs
import re
import threading
import time
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone
from typing import Optional

from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from . import catalog, config, flow, icloud, mailer, publisher, sheets, slots, store, yookassa

log = logging.getLogger("ai2start")

# Стек потока по умолчанию 8 МБ виртуальной памяти. В контейнере с mem_limit и на хосте с подкачкой
# именно создание потока («can't start new thread») первым упирается в нехватку памяти, поэтому
# стек уменьшаем до 1 МБ для всех потоков процесса (задачи тут лёгкие: HTTP, SQLite, CalDAV, SMTP).
threading.stack_size(1024 * 1024)


def _sys_snapshot():
    """Короткая сводка по процессу и cgroup — уходит в тревогу и лог, чтобы по сообщению было видно причину."""
    parts = []
    try:
        for line in open("/proc/self/status").read().splitlines():
            if line.startswith(("Threads:", "VmRSS:")):
                parts.append(" ".join(line.split()))
    except Exception:
        pass
    for path, name in (("/sys/fs/cgroup/memory.current", "mem"), ("/sys/fs/cgroup/memory.max", "mem_max"),
                       ("/sys/fs/cgroup/pids.current", "pids"), ("/sys/fs/cgroup/pids.max", "pids_max")):
        try:
            parts.append(f"{name}={open(path).read().strip()}")
        except Exception:
            pass
    return "; ".join(parts)
EMAIL_RE = re.compile(r"^[^@\s]{1,64}@[^@\s]{1,190}\.[^@\s]{2,}$")


# ---------- занятость ----------
def stream_busy():
    out = []
    for s in catalog.load_streams():
        h, m = (int(x) for x in s["time"].split(":"))
        for d in s["dates"]:
            y, mo, da = (int(x) for x in d.split("-"))
            st = datetime(y, mo, da, h, m, tzinfo=config.TZ)
            out.append((st, st + timedelta(minutes=int(s.get("duration", 90)))))
    return out


def external_busy():
    now = datetime.now(timezone.utc)
    try:
        cal = icloud.fetch_busy(now - timedelta(days=1), now + timedelta(days=config.DAYS_AHEAD + 2))
    except Exception as e:
        log.exception("iCloud недоступен")
        snap = _sys_snapshot()
        log.error("iCloud недоступен: %s | %s", e, snap)
        store.alert_once("icloud", f"Календарь iCloud недоступен, запись закрыта: {e} [{snap}]")
        raise HTTPException(503, "Календарь временно недоступен, попробуйте позже")
    return list(cal) + stream_busy()


def all_busy():
    return external_busy() + store.db_busy()


stream_when = flow.stream_when
booking_when = flow.booking_when


# ---------- оплата ----------
def mark_paid(b):
    with store.LOCK:
        b = store.get(b["id"])
        if b["status"] == "paid":
            return
        conflict = False
        if b["kind"] == "slot" and (b["status"] != "pending" or b["hold_until"] < store.now()):
            start = slots.from_epoch(b["slot_start"])
            others = [x for x in all_busy()]  # своя запись уже не удерживает слот
            conflict = not slots.is_free(start, b["duration_min"], others, before=0, after=0)
        if conflict:
            store.update(b["id"], status="paid_conflict", paid_at=store.now())
            store.outbox_add(f"🚨 Оплата пришла, но окно уже занято. Верните деньги или договоритесь о другом времени.\n"
                             f"{b['title']} · {b['amount']} ₽ · платёж {b['payment_id']}\n{flow.admin_url(b['id'])}")
            return
        store.update(b["id"], status="paid", paid_at=store.now())
    b = store.get(b["id"])
    when = slots.fmt_local(slots.from_epoch(b["slot_start"])) if b["kind"] == "slot" else "по расписанию потока"
    store.outbox_add(f"✅ Оплачено {b['amount']} ₽\n{b['title']}\n{when}\n{flow.admin_url(b['id'])}")


def settle(b, pid=None):
    """сверяемся с ЮKassa: статус берём только оттуда, вебхуку на слово не верим.
    Отменённый платёж запись не снимает: пока окно держится, клиент может оплатить снова."""
    pid = pid or b.get("payment_id")
    if not pid:
        return
    p = yookassa.get_payment(pid)
    ok = (p.get("metadata", {}).get("booking_id") == b["id"]
          and p["amount"]["value"] == f"{b['amount']:.2f}" and p["amount"]["currency"] == "RUB")
    if p["status"] == "succeeded" and ok:
        if b["status"] == "paid" and pid != b.get("payment_id"):
            store.alert_once("dup:" + pid, f"Двойная оплата: {b['title']} · {flow.admin_url(b['id'])} · "
                                           f"{b['amount']} ₽ · лишний платёж {pid}. Сделайте возврат в ЮKassa.", every_s=10 ** 9)
            return
        if pid != b.get("payment_id"):
            store.update(b["id"], payment_id=pid)
        mark_paid(store.get(b["id"]))


def send_confirmation(b):
    meet = f"\nПостоянная ссылка на встречу: {config.MEET_URL}\n" if config.MEET_URL else ""
    mailer.send(b["email"], f"Запись подтверждена: {b['title']}",
        f"Здравствуйте, {b['name']}!\n\nВы записаны: {b['title']}\nВремя: {booking_when(b)}\n{meet}\n"
        "Ссылку на видеовстречу пришлём на эту почту не позднее чем за час до начала.\n"
        "Перенести встречу можно один раз, если написать за сутки: бот поддержки https://t.me/ai2start_bot\n\n"
        "Чек отправит ЮKassa отдельным письмом.\n"
        "Пароли и коды присылать не нужно: на встрече вы вводите их сами.\n\nai2start.ru")


def send_reminder(b, kind):
    left = "завтра" if kind == 24 else "через час"
    meet = f"\nСсылка на встречу: {config.MEET_URL}\n" if config.MEET_URL else ""
    mailer.send(b["email"], f"Напоминание: встреча {left}",
        f"Здравствуйте, {b['name']}!\n\nНапоминаем: {b['title']}\nВремя: {booking_when(b)}\n{meet}\n"
        "Если нужно перенести, напишите в бот поддержки: https://t.me/ai2start_bot\n\nai2start.ru")


def add_calendar(b):
    start = slots.from_epoch(b["slot_start"])
    uid = f"ai2start-{b['id']}@ai2start.ru"
    icloud.add_event(uid, start, start + timedelta(minutes=b["duration_min"]),
                     f"{b['title']} · {b['name']}",
                     f"{b['email']}\n{b['contact'] or ''}\nОплачено {b['amount']} ₽\nплатёж {b['payment_id']}")
    store.update(b["id"], cal_uid=uid)


# ---------- фоновые задачи ----------
def tick():
    t = store.now()
    rows = store.db().execute(
        "SELECT * FROM bookings WHERE status='pending' AND hold_until<?", (t - 120,)).fetchall()
    for r in rows:
        b = dict(r)
        try:
            settle(b)
        except Exception:
            log.exception("settle")
        if store.get(b["id"])["status"] == "pending":
            store.update(b["id"], status="expired")
            flow.on_pay_expired(b)
    flow.tick_requests()
    try:
        sheets.sync()
    except Exception:
        log.exception("sheets")

    recent = store.db().execute("SELECT * FROM bookings WHERE status='paid' AND paid_at>?", (t - 3 * 86400,)).fetchall()
    for r in recent:
        b = dict(r)
        if b["kind"] == "slot" and not b["cal_uid"]:
            try:
                add_calendar(b)
            except Exception as e:
                store.alert_once("cal-write", f"Не удалось записать встречу в календарь: {e}")
        if not store.kv_get("conf:" + b["id"]):
            try:
                send_confirmation(b)
                store.kv_set("conf:" + b["id"], 1)
            except Exception as e:
                store.alert_once("mail", f"Не ушло письмо клиенту ({b['title']}): {flow.safe_err(b, e)}\n{flow.admin_url(b['id'])}")

    upcoming = store.db().execute(
        "SELECT * FROM bookings WHERE status='paid' AND kind='slot' AND slot_start>? AND slot_start<?",
        (t, t + 25 * 3600)).fetchall()
    for r in upcoming:
        b = dict(r)
        left = b["slot_start"] - t
        for flag, kind, lo, hi in (("rem24", 24, 2 * 3600, 24 * 3600), ("rem1", 1, 0, 70 * 60)):
            if not b[flag] and lo < left <= hi:
                try:
                    send_reminder(b, kind)
                    store.update(b["id"], **{flag: 1})
                except Exception as e:
                    store.alert_once("mail", f"Не ушло напоминание ({b['title']}): {flow.safe_err(b, e)}\n{flow.admin_url(b['id'])}")

    now_l = datetime.now(config.TZ)
    today = now_l.strftime("%Y-%m-%d")
    if now_l.hour >= 8 and store.kv_get("digest") != today:
        store.kv_set("digest", today)
        d0 = datetime(now_l.year, now_l.month, now_l.day, tzinfo=config.TZ)
        rows = store.db().execute(
            "SELECT * FROM bookings WHERE status='paid' AND kind='slot' AND slot_start>=? AND slot_start<? ORDER BY slot_start",
            (slots.to_epoch(d0), slots.to_epoch(d0 + timedelta(days=2)))).fetchall()
        waiting = store.db().execute("SELECT COUNT(*) FROM bookings WHERE status='requested'").fetchone()[0]
        lines = []
        if rows:
            lines = [f"📅 Ближайшие встречи"] + [
                f"{slots.fmt_local(slots.from_epoch(r['slot_start']))} — {r['title']}\n{flow.admin_url(r['id'])}" for r in rows]
        if waiting:
            lines.append(f"⏳ Заявок ждут вашего ответа: {waiting}")
        if lines:
            store.outbox_add("\n".join(lines))
    if now_l.hour == 4 and store.kv_get("purged") != today:
        store.kv_set("purged", today)
        store.purge()


def _loop():
    while True:
        try:
            tick()
        except Exception:
            log.exception("tick")
        if threading.active_count() > 25:
            log.warning("много потоков: %s | %s", threading.active_count(), _sys_snapshot())
        time.sleep(60)


@asynccontextmanager
async def lifespan(app):
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    store.db()
    # обычные (sync) ручки FastAPI живут в пуле потоков, по умолчанию до 40 — для этого сервиса много, держим 16
    try:
        import anyio.to_thread
        anyio.to_thread.current_default_thread_limiter().total_tokens = 16
    except Exception:
        log.exception("не удалось ограничить пул потоков")
    threading.Thread(target=_loop, daemon=True, name="jobs").start()
    if config.ICLOUD_USER:
        threading.Thread(target=icloud.loop, daemon=True, name="icloud").start()
    if publisher.enabled():
        threading.Thread(target=publisher.loop, daemon=True, name="publisher").start()
    yield


app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None, lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=config.ALLOWED_ORIGINS,
                   allow_methods=["GET", "POST"], allow_headers=["Content-Type"])


# ---------- публичные ручки ----------
@app.get("/api/health")
def health():
    return {"ok": True}


@app.get("/api/slots")
def get_slots(service: str):
    item = catalog.slot_item(service)
    if not item:
        raise HTTPException(404, "Услуга не найдена")
    title, price, dur = item
    free = slots.free_slots(datetime.now(timezone.utc), dur, all_busy())
    return {"tz": "Europe/Moscow", "title": title, "price": price, "duration_min": dur,
            "slots": [s.strftime("%Y-%m-%dT%H:%M") for s in free]}


@app.get("/api/streams")
def get_streams():
    out = []
    for s in catalog.load_streams():
        name, price = catalog.STREAM_SERVICES[s["service"]]
        left = max(0, int(s["seats"]) - store.stream_taken(s["id"]))
        out.append({"id": s["id"], "title": s["title"], "service": s["service"], "price": price,
                    "dates": s["dates"], "time": s["time"], "seats": int(s["seats"]), "left": left})
    return {"streams": out}


class BookIn(BaseModel):
    kind: str = Field(pattern="^(slot|stream)$")
    service: str = Field(max_length=40)
    slot: Optional[str] = Field(default=None, max_length=20)
    stream: Optional[str] = Field(default=None, max_length=40)
    name: str = Field(min_length=1, max_length=80)
    email: str = Field(max_length=254)
    contact: str = Field(default="", max_length=64)
    consent: bool


@app.post("/api/book")
def book(b: BookIn, request: Request):
    if not b.consent:
        raise HTTPException(400, "Нужно согласие с офертой и политикой")
    email = b.email.strip().lower()
    if not EMAIL_RE.match(email):
        raise HTTPException(400, "Проверьте адрес почты: на него придёт чек и ссылка на встречу")
    name = b.name.strip()
    if not name:
        raise HTTPException(400, "Укажите имя")

    with store.LOCK:
        fields = dict(status="pending", name=name, email=email, contact=b.contact.strip(),
                      consent_at=store.now(), created=store.now(), hold_until=store.now() + config.HOLD_MIN * 60)
        if b.kind == "slot":
            item = catalog.slot_item(b.service)
            if not item or not b.slot:
                raise HTTPException(400, "Выберите услугу и время")
            title, price, dur = item
            try:
                start = slots.parse_local(b.slot)
            except ValueError:
                raise HTTPException(400, "Неверное время")
            free = slots.free_slots(datetime.now(timezone.utc), dur, all_busy())
            if start not in free:
                raise HTTPException(409, "Это окно только что заняли, выберите другое")
            fields.update(kind="slot", service=b.service, title=title, amount=price,
                          slot_start=slots.to_epoch(start), duration_min=dur)
        else:
            s = next((x for x in catalog.load_streams() if x["id"] == b.stream), None)
            if not s or s["service"] != b.service:
                raise HTTPException(404, "Поток не найден")
            if store.stream_taken(s["id"]) >= int(s["seats"]):
                raise HTTPException(409, "В потоке не осталось мест")
            _, price = catalog.STREAM_SERVICES[s["service"]]
            fields.update(kind="stream", service=s["service"], title=s["title"], amount=price, stream_id=s["id"])

        bid = store.new_id()
        if b.kind == "slot":
            fields.update(status="requested", hold_until=flow.request_hold_until(fields["slot_start"], store.now()))
            store.insert(id=bid, **fields)
        else:
            store.insert(id=bid, **fields)
    if b.kind == "slot":
        bk = store.get(bid)
        store.lead_add("booking", bk["service"], bk["title"], name, email, bk["contact"],
                       f"{flow.booking_when(bk)} · {bk['amount']} ₽")
        flow.on_requested(bk)
        return {"booking_id": bid, "status": "requested", "answer_until": flow.fmt_deadline(fields["hold_until"])}
    with store.LOCK:
        try:
            pid, url = yookassa.create_payment(bid, fields["amount"], fields["title"], email,
                                               f"{config.SITE_URL}/?booking={bid}")
        except Exception as e:
            log.exception("создание платежа")
            store.update(bid, status="expired")
            store.alert_once("yk-create", f"Не удалось создать платёж в ЮKassa: {e}")
            raise HTTPException(502, "Оплата временно недоступна, попробуйте позже или напишите в поддержку")
        store.update(bid, payment_id=pid)
    return {"booking_id": bid, "status": "pending", "confirmation_url": url}


class LeadIn(BaseModel):
    item: str = Field(max_length=40)
    name: str = Field(min_length=1, max_length=80)
    email: str = Field(max_length=254)
    contact: str = Field(default="", max_length=64)
    comment: str = Field(default="", max_length=500)
    consent: bool


@app.post("/api/lead")
def lead(l: LeadIn):
    """«Хочу первым»: лист ожидания курса, интенсива или бота"""
    title = catalog.WAITLIST.get(l.item)
    if not title:
        raise HTTPException(404, "Не нашли, на что записываться")
    if not l.consent:
        raise HTTPException(400, "Нужно согласие на обработку данных")
    email = l.email.strip().lower()
    if not EMAIL_RE.match(email):
        raise HTTPException(400, "Проверьте адрес почты: на него напишем, когда откроем запись")
    name = l.name.strip()
    if not name:
        raise HTTPException(400, "Укажите имя")
    if store.lead_recent(l.item, email):
        return {"ok": True, "again": True}
    store.lead_add("waitlist", l.item, title, name, email, l.contact.strip(), l.comment.strip())
    store.outbox_add(f"📝 Лист ожидания: {title}\nКонтакт уже в Google-таблице заявок.")
    try:
        mailer.send(email, f"Вы в листе ожидания: {title}",
                    f"Здравствуйте, {name}!\n\nЗаписали вас в лист ожидания: {title}.\n"
                    "Напишем на эту почту, как только откроем запись, раньше, чем объявим публично.\n\n"
                    f"Вопросы: https://t.me/ai2start_bot\n\nai2start.ru")
    except Exception as e:
        log.warning("mail lead: %s", e)
    return {"ok": True}


@app.get("/api/booking/{booking_id}")
def booking_status(booking_id: str):
    b = store.get(booking_id)
    if not b:
        raise HTTPException(404, "Не найдено")
    if b["status"] == "pending" and b["payment_id"]:
        try:
            settle(b)
            b = store.get(booking_id)
        except Exception:
            log.exception("settle")
    live = b["status"] in ("pending", "requested")
    return {"status": b["status"], "kind": b["kind"], "title": b["title"], "when": booking_when(b),
            "amount": b["amount"],
            "hold_left_s": max(0, b["hold_until"] - store.now()) if live else 0,
            "until": flow.fmt_deadline(b["hold_until"]) if live else ""}


@app.post("/api/booking/{booking_id}/pay")
def booking_pay(booking_id: str):
    try:
        url = flow.payment_url(booking_id)
    except flow.FlowError as e:
        raise HTTPException(e.code, str(e))
    except Exception as e:
        log.exception("платёж")
        store.alert_once("yk-create", f"Не удалось создать платёж в ЮKassa: {e}")
        raise HTTPException(502, "Оплата временно недоступна, попробуйте позже или напишите в поддержку")
    return {"confirmation_url": url}


# ---------- решение владельца по заявке (ссылка из уведомления в Telegram) ----------
def _admin_booking(booking_id, k):
    b = store.get(booking_id)
    if not b or not flow.check_sig(booking_id, k):
        raise HTTPException(404, "Не найдено")
    return b


def _page(b, k, msg=""):
    conflict = False
    if b["status"] == "requested":
        try:
            conflict = flow.calendar_conflict(b, external_busy())
        except HTTPException:
            msg = msg or "Календарь сейчас недоступен, проверьте занятость вручную."
    return HTMLResponse(flow.admin_page(b, k, msg, conflict), headers={"Cache-Control": "no-store"})


@app.get("/admin/b/{booking_id}")
def admin_view(booking_id: str, k: str = ""):
    return _page(_admin_booking(booking_id, k), k)


async def _form(request):
    q = parse_qs((await request.body()).decode("utf-8", "replace"))
    return {x: v[0] for x, v in q.items()}


@app.post("/admin/b/{booking_id}/approve")
async def admin_approve(booking_id: str, request: Request):
    f = await _form(request)
    _admin_booking(booking_id, f.get("k", ""))
    try:
        b, changed = flow.approve(booking_id)
        msg = "Подтверждено. Клиенту ушло письмо со ссылкой на оплату." if changed else "Решение по заявке уже принято."
    except flow.FlowError as e:
        b, msg = store.get(booking_id), str(e)
    return _page(b, f.get("k", ""), msg)


@app.post("/admin/b/{booking_id}/decline")
async def admin_decline(booking_id: str, request: Request):
    f = await _form(request)
    _admin_booking(booking_id, f.get("k", ""))
    try:
        b, changed = flow.decline(booking_id, f.get("note", ""))
        msg = "Отклонено. Клиенту ушло письмо, окно освобождено." if changed else "Решение по заявке уже принято."
    except flow.FlowError as e:
        b, msg = store.get(booking_id), str(e)
    return _page(b, f.get("k", ""), msg)


@app.post("/api/yookassa/webhook")
async def yk_webhook(request: Request):
    try:
        data = await request.json()
        pid = data["object"]["id"]
        bid = (data["object"].get("metadata") or {}).get("booking_id")
    except Exception:
        raise HTTPException(400, "bad payload")
    r = store.db().execute("SELECT * FROM bookings WHERE payment_id=?", (pid,)).fetchone()
    b = dict(r) if r else (store.get(bid) if bid else None)
    if b:
        settle(b, pid)         # ошибка -> 500 -> ЮKassa повторит уведомление; данные берём из ЮKassa, не из вебхука
    return {"ok": True}


# ---------- очередь сообщений для бота в Париже ----------
def _auth(token):
    if not config.OUTBOX_TOKEN:
        raise HTTPException(503, "off")
    if not token or not hmac.compare_digest(token, config.OUTBOX_TOKEN):
        raise HTTPException(401, "no")


@app.get("/internal/outbox")
def outbox(x_token: str = Header(default="")):
    _auth(x_token)
    return {"items": store.outbox_pending()}


class Ack(BaseModel):
    ids: list[int]


@app.post("/internal/outbox/ack")
def outbox_ack(a: Ack, x_token: str = Header(default="")):
    _auth(x_token)
    store.outbox_ack(a.ids)
    return {"ok": True}
