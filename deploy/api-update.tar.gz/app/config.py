import os
from zoneinfo import ZoneInfo

def env(name, default=""):
    return os.environ.get(name, default).strip()

TZ = ZoneInfo(env("TZ_NAME", "Europe/Moscow"))
SITE_URL = env("SITE_URL", "https://ai2start.ru").rstrip("/")
ALLOWED_ORIGINS = [o for o in env("ALLOWED_ORIGINS", "https://ai2start.ru,https://www.ai2start.ru").split(",") if o]

DB_PATH = env("DB_PATH", "/data/ai2start.db")
STREAMS_PATH = env("STREAMS_PATH", "/data/streams.json")

# ЮKassa
YK_SHOP_ID = env("YOOKASSA_SHOP_ID")
YK_SECRET = env("YOOKASSA_SECRET_KEY")
YK_TAX_SYSTEM = int(env("YOOKASSA_TAX_SYSTEM_CODE", "2"))   # 2 = УСН «Доходы»
YK_VAT_CODE = int(env("YOOKASSA_VAT_CODE", "1"))            # 1 = без НДС

# календарь iCloud
ICLOUD_USER = env("ICLOUD_USER")
ICLOUD_PASSWORD = env("ICLOUD_APP_PASSWORD")
READ_CALENDARS = [c.strip() for c in env("READ_CALENDARS", "Саша,Исследования").split(",") if c.strip()]
WRITE_CALENDAR = env("WRITE_CALENDAR", "Записи ai2start")

# почта клиентам
SMTP_HOST = env("SMTP_HOST", "smtp.yandex.ru")
SMTP_PORT = int(env("SMTP_PORT", "465"))
SMTP_USER = env("SMTP_USER")
SMTP_PASSWORD = env("SMTP_PASSWORD")
MAIL_FROM = env("MAIL_FROM", SMTP_USER)
MEET_URL = env("MEET_URL")          # постоянная ссылка на видеовстречу (необязательно)

# выдача очереди сообщений боту в Париже
OUTBOX_TOKEN = env("OUTBOX_TOKEN")

# публикация уведомлений через GitHub (шифрованный файл в ветке)
GH_TOKEN = env("GH_TOKEN")          # fine-grained PAT: только этот репозиторий, Contents: read/write
GH_REPO = env("GH_REPO", "alkuleshov/ai2start")
GH_BRANCH = env("GH_BRANCH", "notify")
NOTIFY_KEY = env("NOTIFY_KEY")      # Fernet-ключ, общий с ботом в Париже

# правила окон
START_TIMES = [(10, 0), (12, 0), (14, 0), (19, 0)]
WEEKDAYS = {0, 1, 2, 3, 4}          # пн–пт
DAYS_AHEAD = int(env("DAYS_AHEAD", "30"))
MIN_NOTICE_H = int(env("MIN_NOTICE_H", "12"))
BUFFER_BEFORE_MIN = int(env("BUFFER_BEFORE_MIN", "30"))
BUFFER_AFTER_MIN = int(env("BUFFER_AFTER_MIN", "60"))
HOLD_MIN = 15                       # удержание места в потоке на время оплаты

# запись через подтверждение владельцем
REQUEST_HOLD_H = int(env("REQUEST_HOLD_H", "24"))   # сколько ждём ответа владельца
PAY_HOLD_H = int(env("PAY_HOLD_H", "24"))           # сколько ждём оплату после подтверждения
NUDGE_AFTER_H = int(env("NUDGE_AFTER_H", "3"))      # напомнить владельцу о неотвеченной заявке
API_PUBLIC_URL = env("API_PUBLIC_URL", "https://api.ai2start.ru").rstrip("/")
ADMIN_KEY = env("ADMIN_KEY")

# общая Google-таблица заявок (та же, что у курсов ai2arch): Apps Script, принимающий JSON
SHEET_WEBHOOK_URL = env("SHEET_WEBHOOK_URL")
SHEET_SOURCE = env("SHEET_SOURCE", "ai2start.ru")                        # подпись ссылок «подтвердить/отклонить»; пусто -> NOTIFY_KEY
