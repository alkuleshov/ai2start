"""Календарь iCloud по CalDAV: читаем занятость из своих календарей, пишем оплаченные записи в «Записи ai2start»."""
import logging
import threading
import time
from datetime import date, datetime, timedelta, timezone

import caldav

from . import config

_lock = threading.Lock()            # запись в календарь
_fetch_lock = threading.Lock()      # одно чтение iCloud за раз
_cache = {"t": 0.0, "busy": None}
CACHE_S = 60          # фоном обновляем раз в минуту
MAX_STALE_S = 1800    # если iCloud тормозит или недоступен, до 30 минут отдаём последнюю занятость
log = logging.getLogger("icloud")

def _client():
    return caldav.DAVClient(url="https://caldav.icloud.com/", username=config.ICLOUD_USER, password=config.ICLOUD_PASSWORD)

def _calendars(principal):
    return {(c.name or c.get_display_name() or ""): c for c in principal.calendars()}

def _search(cal, start, end):
    fn = getattr(cal, "search", None)
    if fn:
        return fn(start=start, end=end, event=True, expand=True)
    return cal.date_search(start=start, end=end, expand=True)

def _to_utc(v):
    if isinstance(v, datetime):
        if v.tzinfo is None:
            v = v.replace(tzinfo=config.TZ)
        return v.astimezone(timezone.utc)
    return None  # date без времени = событие на весь день, не блокирует

def _events(ev):
    inst = ev.icalendar_instance
    for comp in inst.walk("VEVENT"):
        yield comp

def _window():
    now = datetime.now(timezone.utc)
    return now - timedelta(days=1), now + timedelta(days=config.DAYS_AHEAD + 2)


def fetch_busy(start=None, end=None):
    """-> список (начало, конец) aware UTC по календарям READ_CALENDARS.
    Посетитель никогда не ждёт iCloud (3–15 с): отдаём снимок, обновляемый фоном.
    Ждём чтение только при старте или если снимок старше MAX_STALE_S."""
    age = time.time() - _cache["t"]
    if _cache["busy"] is not None and age < MAX_STALE_S:
        if age > CACHE_S:
            _kick()
        return _cache["busy"]
    return refresh()


def _kick():
    if not _fetch_lock.locked():
        threading.Thread(target=_bg, daemon=True, name="icloud-refresh").start()


def _bg():
    try:
        refresh()
    except Exception as e:
        log.warning("фоновое обновление iCloud: %s", e)


def loop():
    while True:
        _bg()
        time.sleep(CACHE_S)


def refresh():
    with _fetch_lock:
        if _cache["busy"] is not None and time.time() - _cache["t"] < CACHE_S / 2:
            return _cache["busy"]           # только что обновил другой поток
        busy = _fetch(*_window())
        _cache.update(t=time.time(), busy=busy)
        return busy


def _fetch(start, end):
    principal = _client().principal()
    cals = _calendars(principal)
    busy = []
    missing = [n for n in config.READ_CALENDARS if n not in cals]
    if missing:
        raise RuntimeError("не найдены календари: " + ", ".join(missing))
    for name in config.READ_CALENDARS:
        for ev in _search(cals[name], start, end):
            for comp in _events(ev):
                if str(comp.get("transp", "")).upper() == "TRANSPARENT":
                    continue
                if str(comp.get("status", "")).upper() == "CANCELLED":
                    continue
                s = _to_utc(comp.get("dtstart").dt) if comp.get("dtstart") else None
                if s is None:
                    continue
                if comp.get("dtend"):
                    e = _to_utc(comp.get("dtend").dt)
                elif comp.get("duration"):
                    e = s + comp.get("duration").dt
                else:
                    e = s + timedelta(hours=1)
                if e and e > s:
                    busy.append((s, e))
    return busy

def invalidate():
    """после записи в календарь: снимок помечаем устаревшим и обновляем фоном"""
    _cache["t"] = min(_cache["t"], time.time() - CACHE_S - 1)
    _kick()

def _esc(s):
    s = str(s)
    for a, b in (("\\", "\\\\"), (";", "\\;"), (",", "\\,"), ("\n", "\\n")):
        s = s.replace(a, b)
    return s

def add_event(uid, start_utc, end_utc, summary, description):
    with _lock:
        cal = _calendars(_client().principal()).get(config.WRITE_CALENDAR)
        if cal is None:
            raise RuntimeError(f"нет календаря «{config.WRITE_CALENDAR}»")
        f = lambda d: d.astimezone(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        ics = "\r\n".join([
            "BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//ai2start//RU", "BEGIN:VEVENT",
            f"UID:{uid}", f"DTSTAMP:{f(datetime.now(timezone.utc))}",
            f"DTSTART:{f(start_utc)}", f"DTEND:{f(end_utc)}",
            f"SUMMARY:{_esc(summary)}", f"DESCRIPTION:{_esc(description)}",
            "END:VEVENT", "END:VCALENDAR", ""])
        cal.save_event(ics)
    invalidate()
