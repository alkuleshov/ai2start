import secrets
import sqlite3
import threading
import time
from datetime import timedelta

from . import config
from .slots import from_epoch

LOCK = threading.RLock()
_local = threading.local()

SCHEMA = """
CREATE TABLE IF NOT EXISTS bookings(
  id TEXT PRIMARY KEY,
  created INTEGER NOT NULL,
  status TEXT NOT NULL,                -- requested | pending | paid | declined | expired | paid_conflict
  kind TEXT NOT NULL,                  -- slot | stream
  service TEXT NOT NULL,
  title TEXT NOT NULL,
  amount INTEGER NOT NULL,
  slot_start INTEGER,                  -- unix, UTC (для kind=slot)
  duration_min INTEGER,
  stream_id TEXT,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  contact TEXT,
  payment_id TEXT,
  hold_until INTEGER,
  paid_at INTEGER,
  cal_uid TEXT,
  consent_at INTEGER NOT NULL,
  rem24 INTEGER NOT NULL DEFAULT 0,
  rem1 INTEGER NOT NULL DEFAULT 0,
  approved_at INTEGER
);
CREATE INDEX IF NOT EXISTS ix_b_status ON bookings(status);
CREATE INDEX IF NOT EXISTS ix_b_slot ON bookings(slot_start);
CREATE TABLE IF NOT EXISTS outbox(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created INTEGER NOT NULL,
  text TEXT NOT NULL,
  sent INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS kv(k TEXT PRIMARY KEY, v TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS leads(           -- лист ожидания и заявки: основная копия здесь (РФ), в Google-таблицу уходит копия
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created INTEGER NOT NULL,
  kind TEXT NOT NULL,                       -- waitlist | booking
  item TEXT NOT NULL,
  title TEXT NOT NULL,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  contact TEXT,
  comment TEXT,
  synced INTEGER NOT NULL DEFAULT 0,
  tries INTEGER NOT NULL DEFAULT 0
);
"""

def db():
    """по одному соединению на поток; WAL позволяет читать параллельно"""
    c = getattr(_local, "c", None)
    if c is None:
        c = sqlite3.connect(config.DB_PATH, timeout=10, isolation_level=None)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA journal_mode=WAL")
        c.execute("PRAGMA busy_timeout=10000")
        c.executescript(SCHEMA)
        try:                                   # миграция старой базы
            c.execute("ALTER TABLE bookings ADD COLUMN approved_at INTEGER")
        except sqlite3.OperationalError:
            pass
        _local.c = c
    return c

def now():
    return int(time.time())

def new_id():
    return secrets.token_urlsafe(12)

def get(booking_id):
    r = db().execute("SELECT * FROM bookings WHERE id=?", (booking_id,)).fetchone()
    return dict(r) if r else None

def insert(**f):
    cols = ",".join(f)
    q = ",".join("?" for _ in f)
    db().execute(f"INSERT INTO bookings({cols}) VALUES({q})", tuple(f.values()))

def update(booking_id, **f):
    sets = ",".join(f"{k}=?" for k in f)
    db().execute(f"UPDATE bookings SET {sets} WHERE id=?", (*f.values(), booking_id))

def db_busy(exclude=None):
    """занятые интервалы из собственной базы: оплаченные, подтверждённые и ожидающие ответа"""
    t = now()
    rows = db().execute(
        "SELECT id, slot_start, duration_min FROM bookings WHERE kind='slot' AND "
        "(status='paid' OR (status IN ('pending','requested') AND hold_until>?))", (t,)).fetchall()
    out = []
    for r in rows:
        if r["id"] == exclude:
            continue
        s = from_epoch(r["slot_start"])
        out.append((s, s + timedelta(minutes=r["duration_min"])))
    return out

def stream_taken(stream_id):
    t = now()
    return db().execute(
        "SELECT COUNT(*) FROM bookings WHERE kind='stream' AND stream_id=? AND "
        "(status='paid' OR (status IN ('pending','requested') AND hold_until>?))", (stream_id, t)).fetchone()[0]

def slot_taken(slot_start_epoch, duration_min):
    """есть ли пересечение с другой записью (учёт отступов делает вызывающий через busy)"""
    return any(True for _ in db().execute(
        "SELECT 1 FROM bookings WHERE kind='slot' AND slot_start=? AND "
        "(status='paid' OR (status IN ('pending','requested') AND hold_until>?))", (slot_start_epoch, now())))

def outbox_add(text):
    db().execute("INSERT INTO outbox(created,text) VALUES(?,?)", (now(), text[:3800]))

def outbox_pending(limit=20):
    return [dict(r) for r in db().execute("SELECT id,text FROM outbox WHERE sent=0 ORDER BY id LIMIT ?", (limit,))]

def outbox_ack(ids):
    ids = [int(i) for i in ids][:200]
    if ids:
        db().execute(f"UPDATE outbox SET sent=1 WHERE id IN ({','.join('?' for _ in ids)})", ids)

def lead_add(kind, item, title, name, email, contact="", comment=""):
    db().execute("INSERT INTO leads(created,kind,item,title,name,email,contact,comment) VALUES(?,?,?,?,?,?,?,?)",
                 (now(), kind, item, title, name, email, contact or "", comment or ""))

def lead_recent(item, email, within_s=86400):
    return db().execute("SELECT 1 FROM leads WHERE item=? AND email=? AND created>?",
                        (item, email, now() - within_s)).fetchone() is not None

def leads_unsynced(limit=20):
    return [dict(r) for r in db().execute(
        "SELECT * FROM leads WHERE synced=0 AND tries<50 ORDER BY id LIMIT ?", (limit,))]

def lead_mark(lid, ok):
    if ok:
        db().execute("UPDATE leads SET synced=1 WHERE id=?", (lid,))
    else:
        db().execute("UPDATE leads SET tries=tries+1 WHERE id=?", (lid,))

def kv_get(k, default=None):
    r = db().execute("SELECT v FROM kv WHERE k=?", (k,)).fetchone()
    return r["v"] if r else default

def kv_set(k, v):
    db().execute("INSERT INTO kv(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v", (k, str(v)))

def alert_once(key, text, every_s=1800):
    """тревога админу не чаще, чем раз в every_s секунд на один ключ"""
    last = int(kv_get("alert:" + key, "0"))
    if now() - last >= every_s:
        kv_set("alert:" + key, now())
        outbox_add("⚠️ " + text)

def purge():
    t = now()
    db().execute("DELETE FROM bookings WHERE status IN ('requested','pending','declined','expired') AND created<?", (t - 30 * 86400,))
    db().execute("DELETE FROM outbox WHERE sent=1 AND created<?", (t - 14 * 86400,))
